
<!doctype html>
<html lang="en">
  <head>
    <?php include_once "./fragments/head.php";?>
    <script src="./js/jquery-1.10.2.js"></script>
    <script src="./js/jquery-1.10.2.min.js"></script>
    <script src="./js/jquery-3.2.1.min.js"></script>
    <script src="./js/jquery.min.js"></script>
    
    <script src="./js/jquery-1.10.2"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>회원가입</title>
    <link rel="icon" type="image/x-icon" href="./img/fork.png"/>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/checkout/">

    

    <!-- Bootstrap core CSS -->
<link href="./css/bootstrap.min - .css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="/css/checkout.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    
<div class="container">
  <main>
    <div class="py-5 text-center">
      <img class="d-block mx-auto mb-4" src="./img/groceries.png" alt="" width="90" height="70">
      <h2><strong>회원 가입</strong></h2>
    </div>
    
        
      <div class="col-md-3 col-lg-12">
        <h3 class="mb-5">회원 정보를 입력하세요</h5>
        <form name="join"  method="post" action="join_ok.php" class="needs-validation" novalidate>
          <div class="row g-2">
            <div class="col-sm-12">
              <label for="id" class="form-label">ID<span class="text-muted"> (중복된 ID면 넘어가지 않습니다)</span></label>
              <input type="text" class="form-control" id="id" name="id" maxlength="15" placeholder="아이디를 입력하세요" value="" required>
              <div class="invalid-feedback">
                Valid ID is required.
              </div>
            </div>

            <div class="col-12">
              <label for="pass" class="form-label mt-3">Password <span class="text-muted">(비밀번호)</span></label>
              <div class="input-group has-validation">
                <!-- <span class="input-group-text">🍙</span> -->
                
                <input type="password" class="form-control" id="pass" name="pass" maxlength="20" placeholder="비밀번호를 입력하세요" required>
              <div class="invalid-feedback">
                  Your password is required.
                </div>
              </div>
            </div>

            <div class="col-12">
              <label for="pass_confirm" class="form-label mt-3">Password Confirm <span class="text-muted">(비밀번호 확인)</span></label>
              <div class="input-group has-validation">
                <!-- <span class="input-group-text">🍙</span> -->
                <input type="password" class="form-control" placeholder="비밀번호 확인" name="pass_confirm" id="pass_confirm" maxlength="20"  required>
              </div>
            </div>

            <div class="form-group">
							<span id="pass_check_msg" data-check="0"></span>	<!--커스텀 속성:data-check="0"  -->
						</div>    



            <div class="col-12">
              <label for="nickname" class="form-label mt-3">NickName<span class="text-muted"></span></label>
              <div class="input-group has-validation">
                 <span class="input-group-text">🍙</span>
              <input type="text" class="form-control" id="nickname" name="nickname" maxlength="20" placeholder="닉네임" required>
            

              </div>
            </div>
            

            <!-- <div class="form-group" style="text-align: center"> -->
              <div class="col-12">
							<div class="btn-group" data-toggle="buttons">
								<label class="btn btn-primary active">
									<input type="radio" name="gender" id="gender1" autocomplete="off" value="남자" checked>남자
								</label>
								<label class="btn btn-primary">
									<input type="radio" name="gender" id="gender2" autocomplete="off" value="여자">여자
								</label>
							</div>
						</div>


          <hr class="my-4">

          <div class="form-check">
            <input type="checkbox" class="form-check-input" id="same-address">
            <label class="form-check-label" for="same-address">서비스 약관을 읽고 동의하였습니다.</label>
          </div>

          <div class="form-check">
            <input type="checkbox" class="form-check-input" id="save-info">
            <label class="form-check-label" for="save-info">개인정보 수집 및 이용, 개인정보 제공에 대한 내용을 확인하였으며, 이에 동의합니다.</label>
          </div>

          <hr class="my-4">

          <span class="btn btn-primary form-control" type="submit" onclick="check_input()">회원가입</span>&nbsp;
						<span class="btn btn-primary form-control" type="submit" onclick="reset_form()">초기화</span>

          <!-- <button class="w-100 btn btn-success btn-lg mt-4" type="submit">가입하기</button> -->
        </form>
      </div>
    </div>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    <p class="mb-5">&copy; 2021 sunmoon project</p>
  </footer>
</div>

<script>

  /* 아이디 중복 체크(비동기통신) */
  $(function(){/*문서가 로드되면 function을 실행하라  */
    $("#id").blur(function(){/*아이디가 id인것을 찾아 포커즈를 빠져나갈때 발생하는 이벤트  */
      if($(this).val()==""){
        $("#id_check_msg").html("아이디를 입력하세요.").css("color","red").attr("data-check","0");/*선택자를 .연사자추가해서 계속 사용가능  */
        $(this).focus();
      }else{
        checkIdAjax();				
      }
    });
  });

  $(function(){/*문서가 로드되면 function을 실행하라  */
    $("#pass_confirm").blur(function(){/*아이디가 id인것을 찾아 포커즈를 빠져나갈때 발생하는 이벤트  */
      if( $(this).val()!=$("#pass").val() ) {
        $("#pass_check_msg").html("비밀번호가 일치하지 않습니다.").css("color","red");
      }else if( ($("#this").val()=="") || ($("#pass").val()=="") ){
        $("#pass_check_msg").html("비밀번호를 입력하세요.").css("color","red");
      }else{
        $("#pass_check_msg").html("비밀번호가 일치합니다.").css("color","blue");
      }
    });
  });

  /* 아이디 중복 체크(비동기통신) */
  function checkIdAjax(){//id값을 post로 전송해서 서버와 통신하여 중복 결과 json 형태로 받아오는 함수
    $.ajax({				//비동기통신방법, 객체로 보낼때{}사용
      url : "./ajax/check_id.php",
      type : "post",
      dataType : "json",
      data : {
        "id" : $("#id").val()
      },
      success : function(data){
        if(data.check){			//json사용했기때문에 data.으로 접근가능
          $("#id_check_msg").html("사용 가능한 아이디입니다.").css("color", "blue").attr("data-check","1");
        }else{
          $("#id_check_msg").html("중복된 아이디입니다.").css("color", "red").attr("data-check","0");
          $("#id").focus();
        }
      }
    });
  }

  function check_input()
     {
     if (!$("#id").val()) {
            alert("아이디를 입력하세요!");    
            $("#id").focus();
            return;
        }

     if (!$("#pass").val()) {
            alert("비밀번호를 입력하세요!");    
            $("#pass").val().focus();
            return;
        }

     if (!$("#pass_confirm").val()) {
            alert("비밀번호확인을 입력하세요!");    
            $("#pass_confirm").focus();
            return;
        }
        
     if (!$("#nickname").val()) {
            alert("닉네임을 입력하세요!");    
            $("#nickname").focus();
            return;
        }

        if ( $("#pass").val() != 
              $("#pass_confirm").val()) {
            alert("비밀번호가 일치하지 않습니다.\n다시 입력해 주세요!");
            $("#pass").focus();
            $("#pass").select();
            return;
        }

        document.join.submit();
     }

     function reset_form() {
        document.join.id.value = "";  
        document.join.pass.value = "";
        document.join.pass_confirm.value = "";
        document.join.nickname.value = "";
        document.join.gender.value = "";
        document.join.id.focus();
        return;
     }
</script>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      <script src="form-validation.js"></script>
  </body>
</html>
